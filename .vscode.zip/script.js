const btn=document.querySelector('.toggle_btn');
btn.addEventListener('click',()=>document.querySelector(".navigation").classList.toggle("active"));